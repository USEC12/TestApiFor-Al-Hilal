﻿namespace WebApplication1.Data;

using Microsoft.EntityFrameworkCore;
using WebApplication1.Model; 

public class ApplicationDbContext : DbContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
        : base(options)
    {
    }

    public DbSet<Product> Products { get; set; } 
}