﻿namespace WebApplication1.Model;

public class PagedResponse<T>
{
    public int TotalItems { get; set; }
    public int TotalPages { get; set; }      // Общее количество страниц
    public int CurrentPage { get; set; }     // Текущая страница
    public int PageSize { get; set; }        // Количество элементов на странице
    public List<T> Items { get; set; }       // Сами данные (продукты)
    
    
    
    public PagedResponse(List<T> items, int count, int pageNumber, int pageSize)
    {
        TotalItems = count;
        PageSize = pageSize;
        CurrentPage = pageNumber;
        TotalPages = (int)Math.Ceiling(count / (double)pageSize);
        Items = items;
    }
}