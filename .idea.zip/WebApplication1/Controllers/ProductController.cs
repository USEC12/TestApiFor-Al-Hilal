﻿
using WebApplication1.Data;
using WebApplication1.Model;
using System.Text;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
namespace WebApplication1.Controllers;


[ApiController]
[Route("api/[controller]")]

public class ProductController : ControllerBase
{
    private readonly ApplicationDbContext _context;

    public ProductController(ApplicationDbContext context)
    {
        _context = context;
    }

    [HttpPost]
    public async Task<ActionResult<Product>> CreateProduct(Product product)
    {
        // Проверка валидности модели
        if (!ModelState.IsValid)
        {
            return BadRequest(ModelState);
        }

        product.DateAdded = DateTime.Now;
        _context.Products.Add(product);
        await _context.SaveChangesAsync();

        return CreatedAtAction(nameof(GetProductById), new { id = product.Id }, product);
        
    }
    // read method for paggination
    [HttpGet]
    public async Task<ActionResult<IEnumerable<Product>>> GetProducts(int pageNumber = 1, int pageSize = 10)
    {
        if (pageNumber <= 0 || pageSize <= 0)
        {
            return BadRequest("Page number and page size must be greater than zero.");
        }

        var totalItems = await _context.Products.CountAsync();

        var products = await _context.Products
            .Skip((pageNumber - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync();

        var pagedResponse = new PagedResponse<Product>(products, totalItems, pageNumber, pageSize);

        return Ok(pagedResponse);
    }
    
    //get product by id
    [HttpGet("{id}")]
    public async Task<ActionResult<Product>> GetProductById(int id)
    {
        var product = await _context.Products.FindAsync(id);

        if (product == null)
        {
            return NotFound();
        }

        return Ok(product);
    }
//update 

    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateProduct(int id, Product product)
    {
       
        // Проверка на совпадение ID
        if (id != product.Id)
        {
            return BadRequest("Product ID mismatch.");
        }

        // Проверка валидности модели
        if (!ModelState.IsValid)
        {
            return BadRequest(ModelState);
        }

        // Найти продукт в базе данных
        var existingProduct = await _context.Products.FindAsync(id);
        if (existingProduct == null)
        {
            return NotFound();
        }

        // Обновляем поля
        existingProduct.Name = product.Name;
        existingProduct.Description = product.Description;
        existingProduct.Price = product.Price;
        existingProduct.DateAdded = product.DateAdded;

        try
        {
            await _context.SaveChangesAsync();
        }
        catch (DbUpdateConcurrencyException)
        {
            if (!ProductExists(id))
            {
                return NotFound();
            }
            else
            {
                throw;
            }
        }

        return NoContent();
    }

    private bool ProductExists(int id)
    {
        return _context.Products.Any(e => e.Id == id);
    }
//delete

    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteProduct(int id)
    {
        var product = await _context.Products.FindAsync(id);
        if (product == null)
        {
            return NotFound();
        }

        try
        {
            _context.Products.Remove(product);
            await _context.SaveChangesAsync();
        }
        catch (Exception ex)
        {
            // Логирование ошибки
            return StatusCode(500, "An error occurred while deleting the product.");
        }

        return NoContent();
    }

    [HttpGet("export")]
    public async Task<IActionResult> ExportToCsv()
    {
        var products = await _context.Products.ToListAsync();

        if (products.Count == 0)
        {
            return NotFound("No products available to export.");
        }

        var csvBuilder = new StringBuilder();
        csvBuilder.AppendLine("Id,Name,Description,Price,DateAdded");

        foreach (var product in products)
        {
            csvBuilder.AppendLine($"{product.Id},{product.Name},{product.Description},{product.Price},{product.DateAdded}");
        }

        var csvData = Encoding.UTF8.GetBytes(csvBuilder.ToString());
        var result = new FileContentResult(csvData, "text/csv")
        {
            FileDownloadName = "products.csv"
        };

        return result;
    }

}